%%
% Se debe seleccionar cual es la fuente. 

%% 
tic 
clear all 
close all 
clc
%% agregar el path 
currentdirectory=pwd;
newpath=[currentdirectory,'\funciones']; 
path(path,newpath)

%% genero el archivo de MCNP 
archivo='D:\Users\sgossio\Desktop\Emergencias_MAT\mcnp_mat.txt';
fid=fopen(archivo, 'w+');
status=fclose(fid);
%% Importante las imagenes en 8-bit 
% hay que usar la funcion uint8
%% Genero los materiales 
mat=f_materiales; 
%% cargo la imagen 
[I,image_info]=f_cargo_imagen(1); % 1 es tiff
I=squeeze(I); %la paso de 4D a 3D 

x=image_info(1,1).Width;
y=image_info(1,1).Height;
z=length(image_info); 
image_size=[x,y,z];  
%% buisco la cantidad de celdas. 
cell=unique(I(:)); %da igual al algoritmo que yo desarrolle. 
%% le agrego un target ncell_fuente=max(cell)+10; 
% se debe preguntar cual es la fuente 
ncell_fuente=max(cell)+10; 
I(15:20,25:30,1:2)=ncell_fuente; 
% 
% % le agrego una fuente-ficticia 
% ncell_fuente=max(cell)+20; 
% I(1:10,15:25,1:2)=ncell_fuente; 
% 
% % grabo la imagen con la fuente 
% % hacer como una funcion y verificar 
% file='D:\Users\sgossio\Desktop\Emergencias_MAT\org+fuente+target.tif';
% for i=1:size(I,3)
%      imwrite(I(:,:,i)./255,file,'tiff','WriteMode','append')
% end

%% voxel con 0 relaveled con 256 (en imageJ es 256)
I(I==0)=256;
%% calculo nuevamente el numero de celdas
cell=unique(I(:)); 
%% asigno los materiales 
IdMat=f_selc_mat(cell,mat); 
%% generio los unioversos 
%a es el tamano 
f_genero_geometria(cell,mat,archivo,image_size,IdMat); 
%% genero el voxel 
tic 
ok=f_genero_voxel_1(I,archivo);
time1=toc/60;
%% genero el final de la sup 
tvoxel=[1 1 1]; %tama�o del voxel en cm hay que preguntarlo
f_genero_geometria_final(archivo,image_size,tvoxel); 
%% genero la fuente
f_genero_fuente(archivo,tvoxel,cell,I,ncell_fuente);
%% agrego los materiales 
f_escribo_materiales(mat,archivo); 
%% agrego las particula y la forma de imprimir 
f_g_numero_part(archivo); 
time=toc/60;
 

