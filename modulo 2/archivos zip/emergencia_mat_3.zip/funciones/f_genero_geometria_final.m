function f_genero_geometria_final(archivo,a,tvoxel)

%% abro el archivo 
fid=fopen(archivo, 'a+'); %agrgar datos al archivo 
xm=a(1)*tvoxel(1);
ym=a(2)*tvoxel(2);
zm=a(3)*tvoxel(3);


%% genero lo que va luego del voxel 
fprintf(fid,'9999   0   1    imp:p=0 \n');
fprintf(fid,'\n');  
%% superficie universo 1
fprintf(fid,'c Superficies \n'); 
fprintf(fid,'1   rpp  0.');
fprintf(fid,'  %g',xm);
fprintf(fid,' 0.');
fprintf(fid,'  %g',ym);
fprintf(fid,' 0.');
fprintf(fid,'  %g \n',zm);
%% universo 2
fprintf(fid,'2   rpp  0. ');
fprintf(fid,' %g',tvoxel(1));
fprintf(fid,' 0.');
fprintf(fid,' %g',tvoxel(2));
fprintf(fid,' 0.');
fprintf(fid,' %g',tvoxel(3));
%% cierro el archivo
status=fclose(fid);
