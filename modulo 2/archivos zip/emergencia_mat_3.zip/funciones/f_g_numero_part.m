function f_g_numero_part(archivo)

nps=100; 

fid=fopen(archivo, 'a+');

fprintf(fid,'c numero de particulas \n'); 
fprintf(fid,'nps '); 
fprintf(fid,'%g',nps); 

fclose(fid)
