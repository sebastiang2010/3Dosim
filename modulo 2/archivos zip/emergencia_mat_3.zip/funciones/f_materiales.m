function mat=f_materiales 

mat(1,1).Nombre='Aire';
mat(1,1).Id=1; 
mat(1,1).Densidad=0.001205;
mat(1,1).Composicion=[6000, -0.000124,7000, -0.755268, 8000, -0.231481, 18000, -0.012827];

mat(2,1).Nombre='Soft Tissue (ICRU 44)';
mat(2,1).Id=2; 
mat(2,1).Densidad=1.06;
mat(2,1).Composicion=[1000, -0.105,6000, -0.143, 7000, -0.034, 8000, -0.708, 11000, -0.002, 15000, -0.003, 16000, -0.003, 17000, -0.002, 19000,-0.003]; 

mat(3,1).Nombre='Adipose Tissue (ICRU 44)';
mat(3,1).Id=3; 
mat(3,1).Densidad=1.02;
mat(3,1).Composicion=[1000, -0.114, 6000, -0.598, 7000, -0.007, 8000, -0.278, 11000, -0.001, 16000, -0.001,17000, -0.001]; 

mat(4,1).Nombre='Bone Cortical (ICRU 44)';
mat(4,1).Id=4; 
mat(4,1).Densidad=1.92;
mat(4,1).Composicion=[1000, -0.034,6000, -0.155, 7000, -0.042, 8000, -0.435, 11000, -0.001, 12000, -0.002,15000, -0.103, 16000, -0.003, 20000, -0.225]; 

mat(5,1).Nombre='Hierro';
mat(5,1).Id=5; 
mat(5,1).Densidad=2.3;
mat(5,1).Composicion=[26000,1];


