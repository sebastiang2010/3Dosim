%%
% agrgra la wwindows
% revisar los ans de mas 
%% 
tic 
clear all 
close all 
clc
%% parametros 
npart=1000; 
n_aire=256; %valor por el que se reamplazaran los ceros 
% se debe preguntar o sacar de la imagen 
tvoxel=[1 1 1]; % en cm  
%% agregar el path 
currentdirectory=pwd;
newpath=[currentdirectory,'\funciones']; 
path(path,newpath)
%% genero el archivo de MCNP 
archivo='D:\Users\sgossio\Desktop\Emergencias_MAT\mcnp_mat.txt';
fid=fopen(archivo, 'w+');
status=fclose(fid);
%% Importante las imagenes en 8-bit 
% hay que usar la funcion uint8
%% Genero los materiales 
mat=f_materiales; 
%% Genero los materiales
fuentes=f_fuentes; 
%% Selecciono las fuentes
idfuente=f_selc_fuente(fuentes);
%% cargo la imagen 
[I,image_info]=f_cargo_imagen(1); % 1 es tiff
I=squeeze(I); %la paso de 4D a 3D 
%% buisco la cantidad de celdas. 
cell=unique(I(:)); %da igual al algoritmo que yo desarrolle. 
%% le agrego un target ncell_fuente=max(cell)+10; 
% se debe preguntar cual es la fuente 
%np=max(cell)+40; 
%% preguntar que celda es la fuente
%I(190:210,240:260,1:2)=np; 

% % le agrego una fuente-ficticia 
% ncell_fuente=max(cell)+20; 
% I(1:10,15:25,1:2)=ncell_fuente; 
% 
% % grabo la imagen con la fuente 
% % hacer como una funcion y verificar 
% file='D:\Users\sgossio\Desktop\Emergencias_MAT\org+fuente+target.tif';
% for i=1:size(I,3)
%      imwrite(I(:,:,i)./255,file,'tiff','WriteMode','append')
% end

%% voxel con 0 relaveled con 256 (en imageJ es 256)
I(I==0)=n_aire;
%%
figure(1); 
for i=1:size(I,3)
    imshow(I(:,:,i),[]);
    colormap(jet)
    pause(0.25)
end
I=f_saco_aire(I,n_aire); 
image_size=size(I); 
%% Giro la matriz para que coincida con el fantoma original 
% realizar una funcion 
% el MCNP lo da vuelta
for i=1:size(I,3)
    I(:,:,i)=flipud(I(:,:,i));
end
%% calculo nuevamente el numero de celdas
cell=unique(I(:));
%% elijo la fuente  
ncell_fuente=f_selc_cell_fuente(cell);
%% asigno los materiales 
IdMat=f_selc_mat(cell,mat); 
%% generio los unioversos 
f_genero_geometria(cell,mat,archivo,image_size,IdMat); 
%% genero el voxel 
tic 
ok=f_genero_voxel_1(I,archivo); 
%ok=f_genero_voxel_2(I,archivo); % terminar de acomodar 
time1=toc/60;
%% genero el final de la sup 
f_genero_geometria_final(archivo,image_size,tvoxel); 
%% genero la fuente
f_genero_fuente(archivo,tvoxel,cell,I,ncell_fuente,idfuente,fuentes);
%% genero el mesh tally 
f_genero_tally(archivo,tvoxel,image_size); 
%% agrego los materiales 
f_escribo_materiales(mat,archivo); 
%% como imprime y la generacion del mctall 
f_g_print(archivo); 
%% genero el numero de particulas
status=f_g_numero_part(archivo,npart);
%%
time=toc/60;

