function f_genero_fuente(archivo,tvoxel,cell,I,ncell_fuente,idfuente,fuentes)

fid=fopen(archivo, 'a+'); %agregar datos al archivo

E_emisividad=fuentes(idfuente,1).E_emisividad; 
Nombre=fuentes(idfuente,1).Nombre; 

E=E_emisividad(:,1)./1000; %esta en KeV hay que pasarla a MeV  
emisividad=E_emisividad(:,2)./100; %esta en porcentaje hay que ponerla como numero  

fprintf(fid,'\n');
fprintf(fid,'c Genero la fuente \n');
fprintf(fid,'mode p \n');
fprintf(fid,'sdef erg d1 x d2 y d3  z d4  cell d5  par=2 \n');% la energia como una distribucion 
fprintf(fid,'c Funte de '); 
fprintf(fid,Nombre);
fprintf(fid,'\n'); 
fprintf(fid,'c sum emisividad %g \n',sum(emisividad(:)));
fprintf(fid,'#    si1   sp1 \n');
fprintf(fid,'       l          d   \n'); 
for i=1:length(E); 
    fprintf(fid,'       %g',E(i)); 
    fprintf(fid,'       %g \n',emisividad(i));
end    
fprintf(fid,'si2 h  0.');
fprintf(fid,'  %g \n',tvoxel(1));
fprintf(fid,'sp2 d  0   1 \n');
fprintf(fid,'si3 h  0.');
fprintf(fid,'  %g \n',tvoxel(2));
fprintf(fid,'sp3 d  0   1 \n');
fprintf(fid,'si4 h  0.');
fprintf(fid,'  %g \n',tvoxel(3));
fprintf(fid,'sp4 d  0   1 \n'); 
%% distribucuion 4 
fprintf(fid,'si5 l');
n=1;
nv_fuente=0;
linea=1;
for k=1:size(I,3)
    [x,y]=find(I(:,:,k)'==ncell_fuente);
    x=x-1;
    y=y-1;
    z=k-1;
    nv_fuente=nv_fuente+length(x); 
    
    for i=1:length(x);
        if linea==1; 
            if n==1
              fprintf(fid,'  (%g',ncell_fuente);
            else
              fprintf(fid,'  (%g',ncell_fuente);
            end
        end 
               
        if linea==2; 
            if n==1
              fprintf(fid,'       (%g',ncell_fuente);
            else
              fprintf(fid,'  (%g',ncell_fuente);
            end
        end 
        fprintf(fid,'<%g',cell(end)+2);
        fprintf(fid,'[%g',x(i));
        fprintf(fid,' %g',y(i));
        fprintf(fid,' %g',z);
        fprintf(fid,']');
        fprintf(fid,'<%g',cell(end)+1);
        fprintf(fid,')');
        
        if n==2;
            fprintf(fid,'\n');
            linea=2; 
            n=1;
        else
            n=n+1;
        end
    end
end
if n==2;fprintf(fid,'\n');end
fprintf(fid,'sp5  1');
fprintf(fid,' %g',nv_fuente-1);
fprintf(fid,'r');



%% cierro el archivo 
fclose(fid);