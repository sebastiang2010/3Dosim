function ncell_fuente=f_selc_cell_fuente(cell) 


 clc
 disp(' Celdas disponibles');
 disp('.....')
 for i=1:length(cell)-1 %la ultima es aire no usar 
     disp([' Celda : ',num2str(cell(i))]);   
 end    
 ncell_fuente=input(' Ingrese la celda que desea utilizar como fuente :');
 parar=1; 
 while parar==1; 
       if ncell_fuente<0 && ncell_funte>max(cell(1:end-1))
          disp(' No es una celda disponible');
       else
           parar=-1; 
       end 
 end
 
 clc