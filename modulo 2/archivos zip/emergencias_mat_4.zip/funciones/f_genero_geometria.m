function f_genero_geometria(cell,mat,archivo,a,idMat)

fid=fopen(archivo, 'a+'); %agregar datos al archivo

fprintf(fid,'c Titulo \n');
fprintf(fid,'c Universos \n');
%% primera linea 
    fprintf(fid,'%g',cell(1));
    fprintf(fid,'    %g',idMat(1)); 
    fprintf(fid,'   -%g',mat(idMat(1),1).Densidad);
    fprintf(fid,'   -2');
    fprintf(fid,'   u=');
    fprintf(fid,'%g',cell(1));  
    fprintf(fid,'   imp:p=1 \n');
%% las cellerfices que siguen 
for i=2:length(cell)-1 % el aire va al final 
    fprintf(fid,'%g ',cell(i)); 
    fprintf(fid,'     like');
    fprintf(fid,'  %g',cell(1)); 
    fprintf(fid,'   but');
    fprintf(fid,'     mat=');
    fprintf(fid,'%g',idMat(i)); 
    fprintf(fid,'    rho=');
    fprintf(fid,'-%g',mat(idMat(i),1).Densidad); 
    fprintf(fid,'    u='); 
    fprintf(fid,'%g',cell(i));
    fprintf(fid,'   imp:p=1  \n'); 
end 
%% agrego las lineas del aire celda 256 (material 1)
fprintf(fid,'%g',cell(end)); 
fprintf(fid,'    like');
fprintf(fid,' %g',cell(1)); 
fprintf(fid,'   but mat=1');
fprintf(fid,'  rho=%g',-mat(1,1).Densidad);
fprintf(fid,'    u=%g',cell(end));
fprintf(fid,'  imp:p=1  \n');
fprintf(fid,'%g',cell(end)+1);
fprintf(fid,'   0             -1          ');
fprintf(fid,'fill=%g',cell(end)+1);
fprintf(fid,'     imp:p=1  \n'); 
fprintf(fid,'%g',cell(end)+2);
fprintf(fid,'   0             -2         lat=1   ');
fprintf(fid,'u=%g',cell(end)+1);
fprintf(fid,'     imp:p=1 \n'); 
fprintf(fid,'                                 fill=0:'); 
fprintf(fid,'%g',a(1)-1);
fprintf(fid,' 0:'); 
fprintf(fid,'%g',a(2)-1);
fprintf(fid,' 0:'); 
fprintf(fid,'%g \n',a(3)-1);

%% cierro el archivo 
fclose(fid);