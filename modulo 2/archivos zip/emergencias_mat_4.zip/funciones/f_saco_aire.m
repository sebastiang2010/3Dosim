function I=f_saco_aire(I,n_aire)

for i=1:size(I,3)
    [x,y]=find(I(:,:,i)~=n_aire);
    x1(i)=min(x);
    y1(i)=min(y);
    x2(i)=max(x);
    y2(i)=max(y);
end

xmin=min(x1);
ymin=min(y1);
xmax=max(x2);
ymax=max(y2);

n=0;
[a,b]=size(I);
if xmax+2<a;n=n+1;end
if xmin-2>1;n=n+1;end
if ymax+2<b;n=n+1;end
if ymin-2>1;n=n+1;end

if n==4;
    I1=I(xmin-2:xmax+2,ymin-2:ymax+2,:);
    figure(50)
    for i=1:size(I1,3)
        imshow(I1(:,:,i),[]);
        colormap(jet)
        pause(0.25)
    end
    clc
    disp('.....')
    resp=input(' La imagen fue recortada correctamente: >0 (SI)  0 (NO) ');
    if resp>0;
        I=I1;
        clear I1
    end
else
    clc
    disp('.....')
    disp(' La imagen no fue modificada ');
end





