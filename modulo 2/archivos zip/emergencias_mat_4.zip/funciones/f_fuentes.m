function fuentes=f_fuentes

%Sacado de Guia Francesa buscar una mejor
%Energia en KeV 
%Emisividad %
fuentes(1,1).Nombre='Ir-192';
fuentes(1,1).Id=1; 
fuentes(1,1).E_emisividad=[317,83;468,48;604,8];

fuentes(2,1).Nombre='Se-75';
fuentes(2,1).Id=2; 
fuentes(2,1).E_emisividad=[136,59;265,59;401,12];

fuentes(3,1).Nombre='Co-60';
fuentes(3,1).Id=3; 
fuentes(3,1).E_emisividad=[1173,100;1333,100];

fuentes(4,1).Nombre='Cs-137';
fuentes(4,1).Id=4; 
fuentes(4,1).E_emisividad=[32,6;36,1;662,85];

fuentes(5,1).Nombre='Yb-169';
fuentes(5,1).Id=4; 
fuentes(5,1).E_emisividad=[51,94;198,35;308,11];

fuentes(6,1).Nombre='Tm-170';
fuentes(6,1).Id=4; 
fuentes(6,1).E_emisividad=[52,3;59,1;84,3];