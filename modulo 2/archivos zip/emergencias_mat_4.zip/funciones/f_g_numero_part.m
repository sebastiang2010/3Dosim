function status=f_g_numero_part(archivo,npart)

fid=fopen(archivo, 'a+');
%% escribo el numero de particulas 
fprintf(fid,'c numero de particulas \n'); 
fprintf(fid,'nps '); 
fprintf(fid,'%g \n',npart); 

%% cierro el archivo 
status=fclose(fid); %entrego el estatus al final 
