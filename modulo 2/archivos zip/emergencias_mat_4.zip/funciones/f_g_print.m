function f_g_print(archivo)

fid=fopen(archivo, 'a+');

fprintf(fid,'c print \n '); 
fprintf(fid,'print \n '); 
fprintf(fid,'prdmp 2j 1 1 j \n');
fprintf(fid,'dbcn 2j 1 50 \n');

fclose(fid);
