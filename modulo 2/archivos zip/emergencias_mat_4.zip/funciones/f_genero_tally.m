function f_genero_tally(archivo,tvoxel,image_size)


fid=fopen(archivo, 'a+'); %agregar datos al archivo

b(1)=image_size(1)*tvoxel(1);
b(2)=image_size(2)*tvoxel(2);
b(3)=image_size(3)*tvoxel(3);

a=b./tvoxel; % numero de separaciones para generar el tally  
a=a-1; 

fprintf(fid,' \n'); 
fprintf(fid,'c tally mesh \n'); 
fprintf(fid,'tmesh \n'); 
fprintf(fid,'rmesh1:p  \n'); 
fprintf(fid,'cora1  0'); 
fprintf(fid,'  %g',a(1));
fprintf(fid,'i');
fprintf(fid,'   %g \n',b(1)); 
fprintf(fid,'corb1  0'); 
fprintf(fid,'  %g',a(2));
fprintf(fid,'i');
fprintf(fid,'   %g \n',b(2));
fprintf(fid,'corc1  0'); 
fprintf(fid,'  %g',a(3));
fprintf(fid,'i');
fprintf(fid,'   %g \n',b(3));
fprintf(fid,'endmd');


fclose(fid);