function idmat=f_selc_mat(cell,mat)


for i=1:size(cell,1)-1; %menos 1 porque la ultima es el aire con 256
    clc
    disp(' La celda 256 corresponde a aire');
    disp('.....')

    for j=1:length(mat);
        disp([mat(j,1).Nombre,' : ',num2str(j)]);
    end

    disp('.....')
    disp(['Material de la celda  :',num2str(cell(i))]);
    disp('.....')
    disp('.....')
    parar=-1;
    while parar==-1;
        n=round(rand*3+1);
        %n=input(' Ingrese el numero del material:  ');
        if n<=length(mat) && n>0;
            idmat(i)=n;
            parar=1;
        else disp(' El numero seleccionado no es valido') 
           
        end
    end
end

clc
