function f_escribo_materiales(mat,archivo)

fid=fopen(archivo, 'a+');

fprintf(fid,'\n');
fprintf(fid,'c materiales');
fprintf(fid,'\n');
for i=1:length(mat)
    fprintf(fid,'c  ');
    fprintf(fid,mat(i,1).Nombre);
    fprintf(fid,'\n');
    fprintf(fid,'m');
    fprintf(fid,'%i',i);
    a=mat(i,1).Composicion;
    n1=1;
    for k=1:length(a)
        if rem(n1,10)==0
          fprintf(fid,' & \n');
          n1=1;
        end 
        n1=n1+1;
        fprintf(fid,' %g',a(k));
    end
    fprintf(fid,'\n');
end
fclose(fid);




