function f_genero_fuente(archivo,tvoxel,cell,I)

fid=fopen(archivo, 'a+'); %agregar datos al archivo

fprintf(fid,'\n');
fprintf(fid,'\n')
fprintf(fid,'c Genero la fuente \n');
fprintf(fid,'mode p \n');
fprintf(fid,'sdef erg=1  x d1 y d2  z d3  cell d4  par=2 \n');% la energia como una distribucion 
fprintf(fid,'si1 h  0.');
fprintf(fid,'  %g \n',tvoxel(1));
fprintf(fid,'sp1 d  0   1 \n'); 
fprintf(fid,'si2 h  0.');
fprintf(fid,'  %g \n',tvoxel(2));
fprintf(fid,'sp2 d  0   1 \n'); 
fprintf(fid,'si3 h  0.');
fprintf(fid,'  %g \n',tvoxel(3));
fprintf(fid,'sp3 d  0   1 \n'); 
%% distribucuion 4 
fprintf(fid,'si4 l');
n=1;
nv_fuente=0;
linea=1;
for k=1:size(I,3)
    [x,y]=find(I(:,:,k)'==cell(end-1));
    x=x-1;
    y=y-1;
    z=k-1;
    nv_fuente=nv_fuente+length(x); 
    
    for i=1:length(x);
        if linea==1; 
            if n==1
              fprintf(fid,'  (%g',cell(end-1));
            else
              fprintf(fid,'  (%g',cell(end-1));
            end
        end 
               
        if linea==2; 
            if n==1
              fprintf(fid,'       (%g',cell(end-1));
            else
              fprintf(fid,'  (%g',cell(end-1));
            end
        end 
        fprintf(fid,'<%g',cell(end)+2);
        fprintf(fid,'[%g',x(i));
        fprintf(fid,' %g',y(i));
        fprintf(fid,' %g',z);
        fprintf(fid,']');
        fprintf(fid,'<%g',cell(end)+1);
        fprintf(fid,')');
        
        if n==3;
            fprintf(fid,'\n');
            linea=2; 
            n=1;
        else
            n=n+1;
        end
    end
end
if n<3;fprintf(fid,'\n');end
fprintf(fid,'sp4  1');
fprintf(fid,' %g',nv_fuente-1);
fprintf(fid,'r');



%% cierro el archivo 
fclose(fid);