function f_genero_geometria(mat,archivo,a)

% ojo deberia mandarlos desde analisis y decir cuantos unidades hay 
cell=10:10:1000;
nmat=4;

fid=fopen(archivo, 'a+'); %agregar datos al archivo

fprintf(fid,'c Titulo \n');
%fprintf(fid,'\n');
fprintf(fid,'c Universos');
fprintf(fid,'\n');
%% primera linea 
    fprintf(fid,'%g',cell(1));
    fprintf(fid,'   2');  %material 2
    fprintf(fid,'   -%g',mat(2,1).Densidad);
    fprintf(fid,'   -2');
    fprintf(fid,'   u=');
    fprintf(fid,'%g',cell(1));  
    fprintf(fid,'   imp:p=1 \n');
%% las cellerfices que siguen 
for i=2:nmat-1 % el aire va al final 
    fprintf(fid,'%g ',cell(i)); 
    fprintf(fid,'     like');
    fprintf(fid,'  %g',cell(1)); 
    fprintf(fid,'   but');
    fprintf(fid,'     mat=');
    fprintf(fid,'%g',i+1); 
    fprintf(fid,'    rho=');
    fprintf(fid,'-%g',mat(i+1,1).Densidad); 
    fprintf(fid,'    u='); 
    fprintf(fid,'%g',cell(i));
    fprintf(fid,'   imp:p=1  \n'); 
end 
%% agrego las lineas del aire celda 256 (material 1)
fprintf(fid,'256     like');
fprintf(fid,' %g',cell(1)); 
fprintf(fid,'   but mat 1  rho=-0.001205 u=256   imp:p=1  \n');
fprintf(fid,'257 0             -1                fill=257 imp:p=1  \n'); 
fprintf(fid,'258 0             -2         lat=1   u=257 imp:p=1 \n'); 
fprintf(fid,'                                 fill=0:'); 
fprintf(fid,'%g',a(1)-1);
fprintf(fid,' 0:'); 
fprintf(fid,'%g',a(2)-1);
fprintf(fid,' 0:'); 
fprintf(fid,'%g \n',a(3)-1);
%% cierro el archivo 
fclose(fid);