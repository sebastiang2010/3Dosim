%% Agregados  
clear all 
close all 
clc

%% Importante las imagenes en 8-bit 

%%
mat=f_materiales; 
%% cargo la imagen 
[I,image_info]=f_cargo_imagen(1); % 1 es tiff
I=squeeze(I); %la paso de 4D a 3D 

x=image_info(1,1).Width;
y=image_info(1,1).Height;
z=length(image_info); 
a=[x,y,z]; %revisar 
%% genero el archivo de MCNP 
archivo='D:\Users\sgossio\Desktop\Emergencias_MAT\mcnp_mat.txt';
fid=fopen(archivo, 'w+');
status=fclose(fid);
%% le agrego una fuente--ficticia 
%I(15:20,50:60,3:7)=255; 
% %grabo como tiff
% % %archivo1=
% for i=1:size(I,3)
%     imwrite(I(:,:,i),'D:\Users\sgossio\Desktop\Emergencias_MAT\4org+funente.tiff','tiff','WriteMode','append')
% end
%% voxel con 0 relaveled con 256 (en imageJ es 256)
I(I==0)=256;
%% 
%nmat=6; % hay que saberlo de ante mano IMP 
f_genero_geometria(mat,archivo,a); 
%% genero el voxel 
tic 
ok=f_genero_voxel_1(I,archivo);
time=toc;
%% genero el final de la sup 
tvoxel=[1 1 1]; %tama�o del voxel en cm 
f_genero_geometria_final(archivo,a,tvoxel); 
%% agrego los materiales 
f_escribo_materiales(mat,archivo); 
%%
f_g_numero_part(archivo); 
